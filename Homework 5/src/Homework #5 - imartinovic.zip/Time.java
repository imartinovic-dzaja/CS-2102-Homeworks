/**
 * Represents time of day (military time)
 * @author Ivan
 *
 */
public class Time {
	private int hours;
	private int minutes;
	
	//Constructor
	public Time (int hours, int minutes) {
		this.hours = hours;
		this.minutes = minutes;
	}
	
}
