
public interface IResult {
	public IContestant getWinner();
	public boolean isValid();
}
